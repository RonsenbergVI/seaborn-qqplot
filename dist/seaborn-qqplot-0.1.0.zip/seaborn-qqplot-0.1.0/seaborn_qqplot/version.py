
# FILE CONTENT GENERATED FROM SETUP.PY
short_version = '0.1.0'
version = '0.1.0'
full_version = '0.1.0'
release = True

if not release:
       version = full_version
	